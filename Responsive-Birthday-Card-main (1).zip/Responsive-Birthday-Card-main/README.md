# Responsive Birthday Card

<p align="left">
  <a href="https://discord.gg/fPrdqh3Zfu" alt="Dev Pro Tips Discussion & Support Server">
    <img src="https://img.shields.io/discord/819650821314052106?color=7289DA&logo=discord&logoColor=white&style=for-the-badge"/></a>
</p>

Responsive Card with HTML and CSS + YouTube tutorial

# Watch the tutorial

https://youtu.be/BVX7kZ4GM-g
